package com.example.HelloWorld

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
